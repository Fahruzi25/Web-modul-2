#!/bin/sh
echo "=========================================="
echo "Hello from Toy Container Engine!"
echo "PID inside container: $$"
echo "Hostname: $(hostname)"
echo "App directory: /app"
echo "=========================================="
